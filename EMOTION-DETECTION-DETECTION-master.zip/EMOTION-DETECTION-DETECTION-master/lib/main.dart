import 'package:flutter/material.dart';
import 'package:emotion_detection/screen_login.dart';
void main()async
{
//   await Firebase.initializeApp(
//     options: DefaultFirebaseOptions.currentPlatform,
// );
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme:ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: ScreenLogin(),
    );

  }
}