import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';

class ScreenContactUs extends StatelessWidget {
  const ScreenContactUs({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title:Text('Contact Us')
      ),
      body:Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children:const [
            Text('Contact Us',
            style:TextStyle(
              fontSize: 40,
              fontWeight: FontWeight.bold,
              color: Colors.purple,
            ),),
            Text('adhin_19b208cs@gecwyd.ac.in',
            style:TextStyle(
              fontSize: 15,
              color: Colors.purple,
            ),
            ),
            Text('nihal_19b071cs@gecwyd.ac.in',
            style:TextStyle(
              fontSize: 15,
              color: Colors.purple,
            ),
            ),
            Text('rahul_19b423cs@gecwyd.ac.in',
            style:TextStyle(
              fontSize: 15,
              color: Colors.purple,
            ),
            ),
            Text('neena_19b054cs@gecwyd.ac.in',
            style:TextStyle(
              fontSize: 15,
              color: Colors.purple,
            ),
            ),
          ],
        ),
      )
    );
  }
}