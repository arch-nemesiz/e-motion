import 'package:emotion_detection/screen_contactus.dart';
import 'package:emotion_detection/screen_devices.dart';
import 'package:emotion_detection/screen_history.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';

class ScreenDashboard extends StatelessWidget {
   ScreenDashboard({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      
      body: SingleChildScrollView(
        child: SafeArea(
          child: Column(
            
            children: [
              Container(
          width: double.infinity,
          height: MediaQuery.of(context).size.height*0.35,
          decoration: BoxDecoration(
            color: Colors.cyan,
            shape: BoxShape.rectangle,
            borderRadius: BorderRadius.circular(10),
          ),
          child:Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: const[
              Padding(
                padding: EdgeInsets.all(8.0),
                child: Text(
                  'Good Morning \nName',
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 40,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
          ),
              const SizedBox(height: 40,),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
              ElevatedButton.icon(
                onPressed: () {},
                icon: Icon(Icons.document_scanner_rounded), // set icon
                label: Text('Current Status'), // set label
                style: ElevatedButton.styleFrom(
                shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10), // adjust border radius as needed
                ),
                backgroundColor: Colors.blue, // set button color
                minimumSize: Size(MediaQuery.of(context).size.width *0.44, MediaQuery.of(context).size.height*0.20), // set minimum button size
                ),
              ),
              ElevatedButton.icon(
                onPressed: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(builder: (ctx)=>ScreenHistory())
                  );
                },
                icon: Icon(Icons.access_time_outlined), // set icon
                label: Text('History'), // set label
                style: ElevatedButton.styleFrom(
                shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10), // adjust border radius as needed
                ),
                backgroundColor: Colors.blue, // set button color
                minimumSize: Size(MediaQuery.of(context).size.width *0.44,MediaQuery.of(context).size.height*0.20), // set minimum button size
                ),
              ),
                ],
              ),
              SizedBox(height: 10,),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
              ElevatedButton.icon(
                onPressed: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(builder: (ctx)=>ScreenDevice())
                  );
                },
                icon: Icon(Icons.devices), // set icon
                label: Text('Devices'), // set label
                style: ElevatedButton.styleFrom(
                shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10), // adjust border radius as needed
                ),
                backgroundColor: Colors.blue, // set button color
                minimumSize: Size(MediaQuery.of(context).size.width *0.44, MediaQuery.of(context).size.height*0.20), // set minimum button size
                ),
              ),
              ElevatedButton.icon(
                onPressed: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(builder: (ctx)=>ScreenContactUs())
                  );
                },
                icon: Icon(Icons.access_time_outlined), // set icon
                label: Text('Contact Us'), // set label
                style: ElevatedButton.styleFrom(
                shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10), // adjust border radius as needed
                ),
                backgroundColor: Colors.blue, // set button color
                minimumSize: Size(MediaQuery.of(context).size.width *0.44, MediaQuery.of(context).size.height*0.20), // set minimum button size
                ),
              ),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}