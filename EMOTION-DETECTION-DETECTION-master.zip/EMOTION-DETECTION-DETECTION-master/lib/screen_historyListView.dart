import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';

class ScreenListView extends StatelessWidget {
  const ScreenListView({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(1),
      child: ListView.separated(
                itemBuilder: (ctx,index)
                {
                  return ListTile(
                    title: Text('History$index',),
                    subtitle: Text('Description'),
                    trailing: Text('Day'),
                  );
                }, 
                separatorBuilder: (ctx,index)
                {
                  return Divider();
                }, 
                itemCount: 10),);
  }
}