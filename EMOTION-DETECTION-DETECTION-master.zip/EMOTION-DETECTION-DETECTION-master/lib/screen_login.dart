import 'package:emotion_detection/screen_home.dart';
import 'package:emotion_detection/screen_signup.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';

class ScreenLogin extends StatelessWidget {
  const ScreenLogin({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      
      body:Container(
        
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(14.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text('Login',
                style:TextStyle(
                  color: Colors.blue,
                  fontSize: 46,
                  fontWeight: FontWeight.bold,
                ) ,),
                const SizedBox(height: 20,),
                TextFormField(
                  decoration:const InputDecoration(
                    border: OutlineInputBorder(),
                    hintText: 'Username'
                  ),
                ),
                const SizedBox(height: 10,),
                TextFormField(
                  decoration:const InputDecoration(
                    border: OutlineInputBorder(
                    ),
                    hintText: 'Password',
                  ),
                  obscureText: true,
                ),
                const SizedBox(height: 10,),
                ElevatedButton(
                  onPressed: (){
                    Navigator.of(context).pushReplacement(
                      MaterialPageRoute(builder: (ctx)=>ScreenHome())
                    );
                  }, 
                  child:const Text('Login')),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text('If you are new to this app?'),
                      TextButton(onPressed: (){
                        Navigator.of(context).push(
                          MaterialPageRoute(builder: (ctx)=>ScreenSignup())
                        );
                      }, child: Text('Signup'),),
                    ],
                  )
              ],
            ),
          )),
      )
    );
  }
}