import 'package:emotion_detection/screen_login.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';

class ScreenAccount extends StatelessWidget {
  const ScreenAccount({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
        child: Padding(
          padding: const EdgeInsets.all(40.0),
          child: Column(
            children: [
              const CircleAvatar(
                radius: 60,
                    backgroundColor: Colors.blue,
                    //backgroundImage: NetworkImage("https://i.pravatar.cc/150?img=3"),
              ),
              const SizedBox(height: 20,),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children:const [
                  Text('Name',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),)
                ],
              ),
              const SizedBox(height: 10,),
              Divider(thickness: 2,),
              const SizedBox(height: 10,),
              Row(
                children:const [
                  Text('Age:',
                  style: TextStyle(
                    fontSize: 20,
                  ),)
                ],
              ),
              const SizedBox(height: 20,),
              Row(
                children:const [
                  Text('Gender:',
                  style: TextStyle(
                    fontSize: 20,
                  ),)
                ],
              ),
              const SizedBox(height: 40,),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text('Guardian Details',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold
                  ),
                  ),
                ],
              ),
              const SizedBox(height: 10,),
                  Divider(thickness: 2,),
                  const SizedBox(height: 10,),
              Row(
                children:const [
                  Text('Guardian Name:',
                  style: TextStyle(
                    fontSize: 20,
                  ),)
                ],
              ),
              const SizedBox(height: 20,),
              Row(
                children:const [
                  Text('Guardian Email:',
                  style: TextStyle(
                    fontSize: 20,
                  ),)
                ],
              ),
              const SizedBox(height: 20,),
              Row(
                children:const [
                  Text('Mobile No1:',
                  style: TextStyle(
                    fontSize: 20,
                  ),)
                ],
              ),
              const SizedBox(height: 20,),
              Row(
                children:const [
                  Text('Mobile No2:',
                  style: TextStyle(
                    fontSize: 20,
                  ),)
                ],
              ),
              const SizedBox(height: 40,),
              
              TextButton(onPressed: (){
                signout(context);
              }, child: Text('Signout'))
            ],
          ),
        ),
      ))
    );
  }

  void signout(BuildContext context)
  {
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (ctx)=>ScreenLogin())
    );
  }
}