import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';

class ScreenSignup extends StatelessWidget {
  const ScreenSignup({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body:SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(13.0),
          child: SafeArea(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text('Register',
                style: TextStyle(
                  color: Colors.blue,
                  fontSize: 48,
                  fontWeight: FontWeight.bold,
                ),),
                const SizedBox(height: 40,),
                TextFormField(
                  decoration:const InputDecoration(
                    border: OutlineInputBorder(),
                    hintText: 'Name'
                  ),
                ),
                const SizedBox(height: 10,),
                TextFormField(
                  decoration:const InputDecoration(
                    border: OutlineInputBorder(),
                    hintText: 'Gender'
                  ),
                ),
                const SizedBox(height: 10,),
                TextFormField(
                  decoration:const InputDecoration(
                    border: OutlineInputBorder(),
                    hintText: 'Age'
                  ),
                ),
                const SizedBox(height: 10,),
                TextFormField(
                  decoration:const InputDecoration(
                    border: OutlineInputBorder(),
                    hintText: 'Guadian Name'
                  ),
                ),
                const SizedBox(height: 10,),
                TextFormField(
                  decoration:const InputDecoration(
                    border: OutlineInputBorder(),
                    hintText: 'Mobile Number'
                  ),
                ),
                const SizedBox(height: 10,),
                TextFormField(
                  decoration:const InputDecoration(
                    border: OutlineInputBorder(),
                    hintText: 'Alternate Mobile Number'
                  ),
                ),
                const SizedBox(height: 10,),
                TextFormField(
                  decoration:const InputDecoration(
                    border: OutlineInputBorder(),
                    hintText: 'Password'
                  ),
                ),
                const SizedBox(height: 10,),
                TextFormField(
                  decoration:const InputDecoration(
                    border: OutlineInputBorder(),
                    hintText: 'Confirm Password'
                  ),
                ),
                const SizedBox(height: 20,),
                ElevatedButton(onPressed: (){}, child: Text('SignUp'))
              ],
            )),
        ),
      )
    );
  }
}